return {
  -- add gruvbox
  { "ellisonleao/gruvbox.nvim" },
}
