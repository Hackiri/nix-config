return {
  -- tokyonight
  {
    "folke/tokyonight.nvim",
    lazy = false,
    opts = {
      style = "moon",
      transparent = true,
      terminal_colors = true,
    },
  },
}
