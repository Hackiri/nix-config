-- https://github.com/darfink/vim-plist
--
-- I use this for editing macos plist files

return {
  { "darfink/vim-plist" },
}
